"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Afeefa Malik
ID:     169060299
Email:  mali0299@mylaurier.ca
__updated__ ="2024-01-13"
------------------------------------------------------------------------
"""

from functions import is_leap_year

year=int(input("Year: "))

leap_year = is_leap_year(year)

print(leap_year)