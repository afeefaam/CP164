"""
------------------------------------------------------------------------
[This program checks to see if a variable name is valid]
------------------------------------------------------------------------
Author: Afeefa Malik
ID:     169060299
Email:  mali0299@mylaurier.ca
__updated__ ="2024-01-13"
------------------------------------------------------------------------
"""

from functions import is_valid

valid = is_valid("2var")

print(valid)