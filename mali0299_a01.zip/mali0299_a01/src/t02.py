"""
------------------------------------------------------------------------
[This program takes the value of repeated items into the second]
------------------------------------------------------------------------
Author: Afeefa Malik
ID:     169060299
Email:  mali0299@mylaurier.ca
__updated__ ="2024-01-13"
------------------------------------------------------------------------
"""

from functions import list_subtraction

minuend=[1,3,5,8,9,10]
subtrahend=[0,2,4,6,8]

list_subtraction(minuend, subtrahend)
print(subtrahend)