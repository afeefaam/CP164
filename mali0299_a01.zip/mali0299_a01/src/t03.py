"""
------------------------------------------------------------------------
[This program removes the values in a string]
------------------------------------------------------------------------
Author: Afeefa Malik
ID:     169060299
Email:  mali0299@mylaurier.ca
__updated__ ="2024-01-13"
------------------------------------------------------------------------
"""

from functions import dsmvwl

out = dsmvwl('I think your book is an utter piece of garbage.')


print(out)