"""
------------------------------------------------------------------------
[This program determines the max abs diff between adjacent values.]
------------------------------------------------------------------------
Author: Afeefa Malik
ID:     169060299
Email:  mali0299@mylaurier.ca
__updated__ ="2024-01-13"
------------------------------------------------------------------------
"""

from functions import max_diff


md = max_diff([40, 20, 10, 5])

print(md)